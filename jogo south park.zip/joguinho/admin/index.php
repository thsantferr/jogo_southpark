﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Poderoso refão ... olha só</title>
</head>
<body>
    <form id="form1" name="form1" method="post" action="admin.php">
        <p>
            <label for="login">Login: </label>
            <input type="text" name="login" id="login" >
        </p>
        <p>
        	<label for="senha">Senha: </label>
            <input type="password" name="pass" id="pass" >
        </p>
        <p>
        	<input type="submit" name="submit" id="submit" value="Vamos Lá">
        </p>
    </form>
</body>
</html>