﻿<?php
	include_once('../config.php');
	if(!verificalogin()){
		header ('location: ../index.php');
		}
?>