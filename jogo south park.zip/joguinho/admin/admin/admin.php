﻿<?php
	include_once('../config.php');
	include_once('funcoes.php');
	//include_once('');
	$login = isset($_POST['login']) ? $_POST['login'] : '' ;
	$senha = isset($_POST['senha']) ? $_POST['senha'] : '' ;
	// se exisir o post pegar o post 
	if(empty($login) || empty($senha)){
			echo '<h1>Preencha todos os campos!</h1>';
			exit;
	}
	$PDO = conecta();
	$sql = 'select * from usuarios where login = :login and senha = :senha';
	$query = $bd->prepare($sql);
	$query->bindParam(':login', $login);
	$query->bindParam(':senha', $senha);
	$query->execute();
	$usuarios = $query->fetchAll(PDO::FETCH_ASSOC);
	if(count($usuarios) <= 0){
		echo '<h1>Seu babaca</h1>';
		exit;
	}
	$usuario = $usuarios[0];
	session_start();
	$_SESSION['logado'] = true;
	$_SESSION['idusuario'] = $usuario['idusuario'];
	$_SESSION['login'] = $usuario['login'];
	header ('location: logado.php')
	
?>
