﻿<?php
	session_start();
	include_once('../config.php');
	include_once('funcoes.php');
	include_once('conferelogin.php');
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Quiz Senac</title>
</head>
<body>
	<h1>Quiz Senac</h1>
    <p><a href="logout.php">Sair</a></p>
</body>
</html>