﻿<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Quiz Senac</title>
</head>
<body>
	<h1>Quiz Senac</h1>
	<form id="form1" name="form1" method="post" action="admin.php">
	  <p>
	    <label for="login">login: </label>
	    <input type="text" name="login" id="login">
      </p>
	  <p>
	    <label for="password">senha:</label>
        <input type="password" name="senha" id="senha">
	  </p>
	  <p>
	    <input type="submit" name="submit" id="submit" value="Entrar">
	  </p>
</form>
	<p>&nbsp;</p>
</body>
</html>