﻿<?php
	//função  de conexão com o banco
	
	function conecta(){
		$PDO =new PDO('mysql:host=' . HOST . '; dbname=' . DB . '; charset=utf8', USER,  PASS); 
		}
	function verificalogin(){
		if(!isset($_SESSION['logado']) || $_SESSION['logado'] !== true){
			return false;
			}
		else { return true;
			}
		}