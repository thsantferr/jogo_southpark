﻿<?php
define('HOST','mysql.hostinger.com.br');
define('DB', 'u293482586_meth');
define('USER', 'u293482586_thsf');
define('PASS', '211332138806');
$dsn = 'mysql:host='. HOST . ';dbname='. DB;
try{
	$bd = new PDO($dsn,USER,PASS);
	$bd->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
}
catch(PDOException $e){
	echo htmlentities('Houve um erro na conexão' . $e->getMessage()); 
} 
?>
